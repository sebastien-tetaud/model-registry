from loguru import logger

from model_registry.connector import MongoDBConnector
from model_registry.db_manager import DbManager
from model_registry.user_manager import UserManager, PasswordGenerator
# from model_registry.utils import PasswordGenerator

if __name__ == "__main__":

    # username = "sebastien"
    # password = "destinepassword"
    username = "admin"
    password = "strongpassword"
    host = "54.37.33.233"
    db_name = "admin"

    connector = MongoDBConnector(username, password, host, db_name)
    client = connector.connect()
    generator = PasswordGenerator(length=16, include_special_chars=False)
    secure_password = generator.generate()

    um = UserManager(client=client)
    um.create_user(database="model_registry",
                user="eric", password=secure_password,
                role="readWrite")

    um.delete_user(user="eric", database="model_registry")


    dm = DbManager(client=client)

    metadata = {
    "project_name": "llm",
    "model_architecture": "SimpleAutoencoderCNN3D",
    "model_version": "9",
    "model_application": "model_registry",
    "outpout_dir": "models/",
    "prediction_dir": "training_inference/",
    "inputs_path": "data/data_inputs.nc",
    "target_path": "data/data_target.nc"}

    dm.store_model(database="model_registry", collection="llm",
                   metadata=metadata, model_path="/home/ubuntu/project/model.onnx")

    dm.delete_model(database="model_registry",
                 collection="llm", model_id="66daf25c3d376cc86e5f990a")
    client.close()